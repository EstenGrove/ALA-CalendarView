export const clearStorage = () => window.localStorage.clear();
