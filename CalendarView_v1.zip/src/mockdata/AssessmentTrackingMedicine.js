export const AssessmentTrackingMedicine = [];
