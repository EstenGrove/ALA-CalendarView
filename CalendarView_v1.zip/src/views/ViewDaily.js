import React from "react";
import styles from "../css/ViewDaily.module.scss";

const ViewDaily = () => {
  return (
    <div className={styles.ViewDaily}>
      {/*  */}
      {/*  */}
      {/*  */}
      {/*  */}
    </div>
  );
};

export default ViewDaily;
