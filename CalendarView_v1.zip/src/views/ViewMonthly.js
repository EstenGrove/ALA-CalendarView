import React from "react";
import styles from "../css/ViewMonthly.module.scss";

const ViewMonthly = () => {
  return (
    <div className={styles.ViewMonthly}>
      {/*  */}
      {/*  */}
      {/*  */}
      {/*  */}
    </div>
  );
};

export default ViewMonthly;
